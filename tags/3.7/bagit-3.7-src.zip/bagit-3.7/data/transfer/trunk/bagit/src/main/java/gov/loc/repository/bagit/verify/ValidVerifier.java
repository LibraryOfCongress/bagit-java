package gov.loc.repository.bagit.verify;

public interface ValidVerifier extends Verifier {

}
