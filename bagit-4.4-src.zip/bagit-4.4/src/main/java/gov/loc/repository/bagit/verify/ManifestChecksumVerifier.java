package gov.loc.repository.bagit.verify;

public interface ManifestChecksumVerifier extends ManifestVerifier {

}
