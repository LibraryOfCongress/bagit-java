package gov.loc.repository.bagit;

import gov.loc.repository.bagit.utilities.namevalue.NameValueReader;

public interface BagItTxtReader extends NameValueReader {

}
