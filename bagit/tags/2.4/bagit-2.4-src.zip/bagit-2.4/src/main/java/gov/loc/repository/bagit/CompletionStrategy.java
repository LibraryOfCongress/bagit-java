package gov.loc.repository.bagit;

public interface CompletionStrategy {

	void complete(Bag bag);
}
