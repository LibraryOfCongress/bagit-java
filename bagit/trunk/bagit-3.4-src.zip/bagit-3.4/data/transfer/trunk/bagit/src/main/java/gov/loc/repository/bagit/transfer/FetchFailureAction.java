package gov.loc.repository.bagit.transfer;

/**
 * The action a fetch operation should take as a response
 * to failures.
 * 
 * @version $Id: FetchFailureAction.java 2270 2009-09-22 15:52:35Z brian $
 * @see FetchFailStrategy
 */
public enum FetchFailureAction
{
	RETRY_CURRENT,
	CONTINUE_WITH_NEXT,
	STOP
}
