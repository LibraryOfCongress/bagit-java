package gov.loc.repository.bagit.filesystem;

public interface FileSystemNodeFilter {
	boolean accept(FileSystemNode fileSystemNode);
}
